# ALEX ODINN — LUCKY SPIN (CLOUDFLARE EDITION)

A prize wheel based on the existing Alex Lucky Spin design, rebuilt for **Cloudflare Workers + D1**. It runs online with no software installed on your own computer. The code in this ZIP is independent of the original Nings site's source, branding, and images.

**Budget:** Cloudflare Workers Free + D1 Free + the included `*.workers.dev` address cost **$0** within free-plan limits. No domain purchase is necessary. You must stay within the provider's free quotas. Check https://developers.cloudflare.com/workers/platform/pricing/ and https://developers.cloudflare.com/d1/platform/pricing/ for current limits.

## What you get

- The same original Icelandic landing-page design, animated wheel, and prize list.
- Real 1%, 1%, 1%, 2%, 5%, 10%, 20%, 60% server-side outcomes.
- A Cloudflare **D1 database** that keeps player history and winner codes across deployments.
- One recorded entry per TikTok username and signed browser cookie, per campaign.
- Admin dashboard (`/admin`), claim status updates, CSV export (up to 5,000 most recent entries).
- Zero required paid APIs, and no Node.js installation on your PC.

## Setup (ALL IN THE BROWSER, step by step)

### 1. Create a free database

1. Sign in at https://dash.cloudflare.com/ and select the **Free** plan if asked.
2. Find **Workers & Pages → D1 SQL Database** (the wording may vary) and choose **Create database**.
3. Name it **`alex-lucky-spin`**.
4. Open the new database → **Console**.
5. Open `schema.sql` from this ZIP in a text editor and paste **all** its contents into the Console. Click **Execute**. Then check that a table called `spins` exists.
6. Copy the database's UUID/Database ID from its Overview or Settings screen.

### 2. Put your code on GitHub

1. Extract this ZIP on your PC. This extracts files only; it installs nothing.
2. In the extracted folder, open `wrangler.jsonc` using Notepad.
3. Replace `REPLACE_WITH_YOUR_D1_DATABASE_ID` with the UUID from step 1. **Keep the quotation marks**. Save.
4. At https://github.com/new create a **private** repository, perhaps `alex-lucky-spin`.
5. From the new repository choose **Add file → Upload files** and drag in all files and folders from *inside* `alex-lucky-spin-cloudflare` (not the ZIP itself): `src`, `public`, `schema.sql`, `wrangler.jsonc`, `package.json`, etc. Commit changes.

### 3. Deploy on Cloudflare (still no Node.js on your PC)

1. Go to https://dash.cloudflare.com/ → **Workers & Pages → Create application**.
2. Choose GitHub, connect your GitHub account, and select the new private repository.
3. **Important:** Set the Worker/project name to `alex-lucky-spin`, matching `"name"` in `wrangler.jsonc`. If this name is already in use on your Cloudflare account, update both names to the same unique value.
4. Use the repository root as the **Root directory** (leave blank or `/` according to the form).
5. **Build command:** leave blank if allowed. **Deploy command:** `npx wrangler deploy`.
6. Deploy. Cloudflare's build servers run Wrangler for you. You do not install Node.js or npm locally.
7. Cloudflare gives you a free site address like `https://alex-lucky-spin.YOUR-SUBDOMAIN.workers.dev`.

### 4. Set your two private secrets (required before real spins)

In **Workers & Pages → alex-lucky-spin → Settings → Variables and Secrets**, add two **Secret** values:

- `ADMIN_KEY`: pick a **unique, random** password of at least 16 characters (32+ recommended). You will type this same password on `/admin`.
- `COOKIE_SECRET`: a **different**, random string of at least 32 characters. This signs players' cookies so they cannot simply forge one. Do not share it.

Press **Deploy** / save when prompted. **Never put your secret values into GitHub or `wrangler.jsonc`.**

The `DB` database binding is already defined in `wrangler.jsonc`; do not create an extra binding with a different name.

### 5. Test before sharing on TikTok

1. Open the `workers.dev` URL and submit a test username (not a real user).
2. Try spinning again with the same username: it must be blocked.
3. Open `https://YOUR-URL/admin` and enter `ADMIN_KEY`.
4. Check that your test entry appears and that CSV export works.
5. Redeploy once and check the entry still exists. **It should: D1 is persistent.**
6. To make a fresh public campaign after testing, change `CAMPAIGN_ID` under `"vars"` in `wrangler.jsonc` to something new, e.g. `alex-live-nov-2026`, then commit the change on GitHub. Prior records remain in D1 but the new campaign starts fresh.

## Changing prizes

Edit `src/prizes.js`: the `chance` values are actual server-side percentages and **must add up to 100**. Also edit `FALLBACK_PRIZES` in `public/app.js` if you want the offline demo to look the same. The frontend spins to the real server-selected outcome. Like the original version, displayed slices are equal-sized for readability, not proportional to odds.

## Important limitations

- **This version is for a small giveaway**, not a security-proof account-verification platform. Someone can enter multiple usernames or impersonate a TikTok user. Ask winners to DM the displayed claim code **from the TikTok account they entered**; verify manually before delivering a prize.
- It does **not** automatically follow accounts, like videos, post comments or verify TikTok identity. You deliver prizes yourself.
- Free Worker requests and D1 queries have daily limits. Exceeding the free quota can temporarily block visits or spins until the quota resets. No automatic upgrade is needed for this package.
- The database is durable, but keep periodic backups using D1's export options. Do not delete it when redeploying.
- Before going public, publish clear giveaway rules (who can enter, closing date, odds, what each prize entails, how winners are contacted), a privacy notice, and a contact method. Ensure the giveaway follows relevant law and TikTok rules.
- One-spin enforcement is best-effort, not bulletproof bot prevention. Add CAPTCHA and stronger verification if participation grows substantially.
- Admin dashboard lists the latest **5,000** entries of the current campaign; backups and D1 directly hold any additional entries.

## Code layout

```
public/             landing page, wheel, CSS, admin dashboard
src/worker.js       server-side outcomes, player cookies, prize claims, D1 queries
src/prizes.js       actual prize probabilities
schema.sql          D1 table and index definitions
wrangler.jsonc      Cloudflare deployment and database binding config
package.json       build-time Wrangler package, installed by Cloudflare on its servers
test/               automated endpoint tests for developers
```

For more info: https://developers.cloudflare.com/workers/ci-cd/builds/ and https://developers.cloudflare.com/d1/get-started/
