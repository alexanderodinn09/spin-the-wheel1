import assert from 'node:assert/strict';
import test from 'node:test';
import fs from 'node:fs';
import { DatabaseSync } from 'node:sqlite';
import worker, { pickPrize } from '../src/worker.js';
import PRIZES from '../src/prizes.js';

class Statement {
  constructor(db, sql, params=[]) { this.db=db;this.sql=sql;this.params=params; }
  bind(...params) { return new Statement(this.db,this.sql,params); }
  first() { return this.db.prepare(this.sql).get(...this.params) || null; }
  all() { return {results:this.db.prepare(this.sql).all(...this.params)}; }
  run() { const r=this.db.prepare(this.sql).run(...this.params);return {meta:{changes:r.changes}}; }
}
const db = new DatabaseSync(':memory:');
db.exec(fs.readFileSync(new URL('../schema.sql',import.meta.url), 'utf8'));
const env = { DB:{prepare(sql){return new Statement(db,sql);}},
  ADMIN_KEY:'some-private-admin-key-at-least-16',
  COOKIE_SECRET:'some-long-high-entropy-secret-for-unit-tests-only',
  CAMPAIGN_ID:'test-campaign',
  ASSETS:{fetch:async req=>new Response(`Asset: ${new URL(req.url).pathname}`)} };
const root='https://test.example';
const call=(pathname, opts={})=>worker.fetch(new Request(root+pathname, opts),env);

test('prize weights are exactly 100 and outcomes are from configured prizes',()=>{
  assert.equal(PRIZES.reduce((n,p)=>n+p.chance,0),100);
  const seen = new Set();
  for(let i=0;i<2000;i++){const result=pickPrize();assert.ok(PRIZES.includes(result));seen.add(result.id);}
  assert.ok(seen.has('nothing'));
});

test('config, spin, duplicate prevention, admin, claims and CSV',async()=>{
  const first=await call('/api/config');
  assert.equal(first.status,200);
  const cookie=first.headers.get('Set-Cookie').split(';')[0];
  assert.ok(cookie.startsWith('alexspin='));
  assert.equal((await first.json()).alreadyPlayed,null);
  const requestInit={method:'POST',headers:{cookie,'content-type':'application/json',origin:root},body:JSON.stringify({username:'@testuser'})};
  const result=await call('/api/spin',requestInit);
  assert.equal(result.status,200);
  const resultJson=await result.json();
  assert.equal(resultJson.result.username,'testuser');
  assert.ok(PRIZES.some(p=>p.id===resultJson.result.prize.id));
  const second=await call('/api/spin', {...requestInit,body:JSON.stringify({username:'seconduser'})});
  assert.equal(second.status,409);
  assert.equal((await second.json()).alreadyPlayed.username,'testuser');
  const other=await call('/api/config');
  const otherCookie=other.headers.get('Set-Cookie').split(';')[0];
  const claimed=await call('/api/spin',{...requestInit,headers:{...requestInit.headers,cookie:otherCookie}});
  assert.equal(claimed.status,409);
  const existing=await call('/api/config',{headers:{cookie}});
  assert.equal((await existing.json()).alreadyPlayed.username,'testuser');
  const noAuth=await call('/api/admin/spins');
  assert.equal(noAuth.status,401);
  const loginHeaders={'X-Admin-Key':env.ADMIN_KEY};
  const admin=await call('/api/admin/spins',{headers:loginHeaders});
  const adminData=await admin.json();
  assert.equal(adminData.spins.length,1);
  assert.equal(adminData.spins[0].username,'testuser');
  const csv=await call('/api/admin/export',{headers:loginHeaders});
  assert.equal(csv.status,200);
  assert.match(await csv.text(), /testuser/);
  // Enable status adjustment by making it a winner in test DB.
  db.prepare('UPDATE spins SET prize_id = ?, status = ?, code = ? WHERE username = ?')
    .run('follow','pending','TEST1234','testuser');
  const updated=await call('/api/admin/spins/'+resultJson.result.id,{method:'PATCH',headers:{...loginHeaders,'content-type':'application/json',origin:root},body:JSON.stringify({status:'fulfilled'})});
  assert.equal(updated.status,200);
  assert.equal(db.prepare('SELECT status FROM spins WHERE username = ?').get('testuser').status,'fulfilled');
});

test('reject wrong-origin spins and broken secrets',async()=>{
  const badOrigin=await call('/api/spin',{method:'POST',headers:{origin:'https://attacker.example','content-type':'application/json'},body:JSON.stringify({username:'intruder'})});
  assert.equal(badOrigin.status,403);
  const noDb=await worker.fetch(new Request(root+'/api/config'), {...env,DB:null});
  assert.equal(noDb.status,503);
});

test('serve admin-friendly URL from static assets', async()=>{
  const html=await call('/admin');
  assert.equal(html.status,200);
  assert.equal(await html.text(),'Asset: /admin.html');
});
