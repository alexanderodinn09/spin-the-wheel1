import PRIZES from './prizes.js';

// Cloudflare Worker + D1 backend. Real draws happen only here, not in the browser.
// IMPORTANT: Bind D1 as DB; set secrets ADMIN_KEY and COOKIE_SECRET in Cloudflare.
const encoder = new TextEncoder();
const HEADERS = {
  'Cache-Control': 'no-store',
  'X-Content-Type-Options': 'nosniff',
  'Referrer-Policy': 'strict-origin-when-cross-origin',
  'X-Frame-Options': 'DENY',
  'Content-Security-Policy': "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; font-src 'self'; base-uri 'none'; object-src 'none'; frame-ancestors 'none'"
};
const json = (payload, status = 200, headers = {}) => new Response(JSON.stringify(payload), {
  status, headers: { ...HEADERS, 'Content-Type': 'application/json; charset=utf-8', ...headers }
});
function errorResponse(error) {
  console.error('Lucky Spin request error:', error);
  return json({ error: 'Villa kom upp. Reyndu aftur.' }, 500);
}
function hex(bytes) { return [...bytes].map(x => x.toString(16).padStart(2, '0')).join(''); }
function randomHex(n) { return hex(crypto.getRandomValues(new Uint8Array(n))); }
async function sha256(s) { return hex(new Uint8Array(await crypto.subtle.digest('SHA-256', encoder.encode(s)))); }
async function hmac(s, secret) {
  const key = await crypto.subtle.importKey('raw', encoder.encode(secret), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
  return hex(new Uint8Array(await crypto.subtle.sign('HMAC', key, encoder.encode(s))));
}
function equal(a, b) {
  if (typeof a !== 'string' || typeof b !== 'string' || a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return diff === 0;
}
function campaign(env) { return env.CAMPAIGN_ID || 'alex-launch-2026'; }
function getPrize(id) { return PRIZES.find(p => p.id === id); }
function publicSpin(record) {
  if (!record) return null;
  const prize = getPrize(record.prize_id);
  return {
    id: record.id, username: record.username,
    prize: { id: prize.id, title: prize.title, description: prize.description, win: prize.win },
    code: prize.win ? record.code : null,
    createdAt: record.created_at, status: record.status
  };
}
export function pickPrize() {
  // Rejection sampling avoids modulo bias in exactly weighted 0..99 tickets.
  const limit = 4294967296 - (4294967296 % 100);
  let ticket;
  do { ticket = crypto.getRandomValues(new Uint32Array(1))[0]; } while (ticket >= limit);
  ticket %= 100;
  let ceiling = 0;
  for (const prize of PRIZES) {
    ceiling += prize.chance;
    if (ticket < ceiling) return prize;
  }
  throw new Error('Invalid prize configuration');
}
function normalizeHandle(input) {
  if (typeof input !== 'string') return null;
  const handle = input.trim().replace(/^@/, '').toLowerCase();
  return /^[a-z0-9._]{2,24}$/.test(handle) ? handle : null;
}
function sameOrigin(req) {
  const origin = req.headers.get('Origin');
  if (!origin) return true;
  try { return new URL(origin).origin === new URL(req.url).origin; } catch { return false; }
}
async function session(req, env) {
  const cookie = req.headers.get('Cookie') || '';
  const found = cookie.split(';').map(x => x.trim()).find(x => x.startsWith('alexspin='))?.slice(9) || '';
  const match = /^([a-f0-9]{48})\.([a-f0-9]{64})$/.exec(found);
  if (match && equal(match[2], await hmac(match[1], env.COOKIE_SECRET))) {
    return { sidHash: await sha256(match[1]), cookieHeader: null };
  }
  const sid = randomHex(24);
  const signature = await hmac(sid, env.COOKIE_SECRET);
  const secure = new URL(req.url).protocol === 'https:' ? '; Secure' : '';
  const cookieHeader = `alexspin=${sid}.${signature}; HttpOnly; SameSite=Lax; Path=/; Max-Age=2592000${secure}`;
  return { sidHash: await sha256(sid), cookieHeader };
}
const withCookie = sid => sid.cookieHeader ? { 'Set-Cookie': sid.cookieHeader } : {};
async function readBody(req) {
  if (Number(req.headers.get('Content-Length') || 0) > 8000) return null;
  const body = await req.text();
  if (body.length > 8000) return null;
  try { return JSON.parse(body); } catch { return null; }
}
function adminAuthorized(req, env) {
  const key = req.headers.get('X-Admin-Key');
  return typeof env.ADMIN_KEY === 'string' && env.ADMIN_KEY.length >= 16 &&
    typeof key === 'string' && equal(key, env.ADMIN_KEY);
}
async function listSpins(env) {
  const { results } = await env.DB.prepare(
    'SELECT id, username, prize_id, code, status, created_at FROM spins WHERE campaign_id = ? ORDER BY created_at DESC LIMIT 5000'
  ).bind(campaign(env)).all();
  return results.map(row => ({
    id: row.id, username: row.username, prizeId: row.prize_id,
    prizeTitle: getPrize(row.prize_id)?.title || row.prize_id,
    won: !!getPrize(row.prize_id)?.win, code: row.code,
    status: row.status, createdAt: row.created_at
  }));
}
async function exportCsv(env) {
  const rows = [['Dags.', 'TikTok', 'Vinningur', 'Kóði', 'Staða', 'Herferð']];
  // Protect the free tier from large unbounded exports; CSV covers up to 5000 newest entries.
  const { results } = await env.DB.prepare(
    'SELECT created_at, username, prize_id, code, status, campaign_id FROM spins WHERE campaign_id = ? ORDER BY created_at DESC LIMIT 5000'
  ).bind(campaign(env)).all();
  for (const s of results) rows.push([s.created_at, '@' + s.username, getPrize(s.prize_id)?.title || s.prize_id,
    s.code || '', s.status, s.campaign_id]);
  const csv = '\ufeff' + rows.map(row => row.map(v => '"' + String(v).replace(/"/g, '""') + '"').join(',')).join('\r\n');
  return new Response(csv, { headers: {
    ...HEADERS, 'Content-Type': 'text/csv; charset=utf-8',
    'Content-Disposition': 'attachment; filename="alex-winners.csv"'
  }});
}
export default {
  async fetch(req, env) {
    try {
      const url = new URL(req.url), route = url.pathname;
      if (route === '/admin' && req.method === 'GET') {
        const assetURL = new URL('/admin.html', req.url);
        return env.ASSETS.fetch(new Request(assetURL, req));
      }
      if (!route.startsWith('/api/')) return env.ASSETS.fetch(req);
      if (!env.DB || typeof env.COOKIE_SECRET !== 'string' || env.COOKIE_SECRET.length < 32) {
        return json({ error: 'Server er ekki fullstilltur. Vantar gagnagrunn eða COOKIE_SECRET.' }, 503);
      }
      if (route === '/api/config' && req.method === 'GET') {
        const sid = await session(req, env);
        const existing = await env.DB.prepare('SELECT * FROM spins WHERE campaign_id = ? AND sid_hash = ?')
          .bind(campaign(env), sid.sidHash).first();
        return json({ campaignId: campaign(env), prizes: PRIZES, alreadyPlayed: publicSpin(existing) }, 200, withCookie(sid));
      }
      if (route === '/api/spin' && req.method === 'POST') {
        if (!sameOrigin(req)) return json({ error: 'Óleyfileg beiðni.' }, 403);
        const sid = await session(req, env);
        const body = await readBody(req);
        const handle = normalizeHandle(body?.username);
        if (!handle) return json({ error: 'Sláðu inn gilt TikTok-notandanafn.' }, 400, withCookie(sid));
        const earlier = await env.DB.prepare('SELECT * FROM spins WHERE campaign_id = ? AND sid_hash = ?')
          .bind(campaign(env), sid.sidHash).first();
        if (earlier) return json({ error: 'Þú hefur þegar snúið hjólinu.', alreadyPlayed: publicSpin(earlier) }, 409, withCookie(sid));
        const prize = pickPrize(), id = crypto.randomUUID();
        const record = { id, username: handle, prize_id: prize.id,
          code: prize.win ? randomHex(4).toUpperCase() : null,
          status: prize.win ? 'pending' : 'none', created_at: new Date().toISOString() };
        // Atomic insert: unique campaign+username and campaign+signed-session constraints.
        const insertion = await env.DB.prepare(
          'INSERT OR IGNORE INTO spins (id, campaign_id, username, sid_hash, prize_id, code, status, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
        ).bind(id, campaign(env), handle, sid.sidHash, record.prize_id, record.code, record.status, record.created_at).run();
        if (!insertion.meta?.changes) {
          const duplicate = await env.DB.prepare('SELECT * FROM spins WHERE campaign_id = ? AND sid_hash = ?')
            .bind(campaign(env), sid.sidHash).first();
          return json({ error: 'Þetta TikTok-notandanafn hefur þegar tekið þátt.', ...(duplicate ? { alreadyPlayed: publicSpin(duplicate) } : {}) }, 409, withCookie(sid));
        }
        return json({ result: publicSpin(record) }, 200, withCookie(sid));
      }
      if (route.startsWith('/api/admin/')) {
        if (!adminAuthorized(req, env)) return json({ error: 'Rangur aðgangslykill eða stjórnborð óvirkt.' }, 401);
        if (route === '/api/admin/spins' && req.method === 'GET') {
          return json({ campaignId: campaign(env), spins: await listSpins(env) });
        }
        if (route === '/api/admin/export' && req.method === 'GET') return exportCsv(env);
        const match = /^\/api\/admin\/spins\/([0-9a-f-]{36})$/.exec(route);
        if (match && req.method === 'PATCH') {
          if (!sameOrigin(req)) return json({ error: 'Óleyfileg beiðni.' }, 403);
          const payload = await readBody(req);
          if (!['pending', 'fulfilled', 'rejected'].includes(payload?.status)) return json({ error: 'Ógild staða.' }, 400);
          const row = await env.DB.prepare('SELECT * FROM spins WHERE id = ? AND campaign_id = ?')
            .bind(match[1], campaign(env)).first();
          if (!row) return json({ error: 'Vinningur fannst ekki.' }, 404);
          if (!getPrize(row.prize_id)?.win) return json({ error: 'Enginn vinningur.' }, 400);
          await env.DB.prepare('UPDATE spins SET status = ? WHERE id = ? AND campaign_id = ?')
            .bind(payload.status, match[1], campaign(env)).run();
          return json({ ok: true });
        }
      }
      return json({ error: 'Not found' }, 404);
    } catch (err) { return errorResponse(err); }
  }
};
