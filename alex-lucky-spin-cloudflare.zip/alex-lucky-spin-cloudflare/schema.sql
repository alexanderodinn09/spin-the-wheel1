CREATE TABLE IF NOT EXISTS spins (
  id TEXT PRIMARY KEY NOT NULL,
  campaign_id TEXT NOT NULL,
  username TEXT NOT NULL,
  sid_hash TEXT NOT NULL,
  prize_id TEXT NOT NULL,
  code TEXT,
  status TEXT NOT NULL,
  created_at TEXT NOT NULL,
  UNIQUE(campaign_id, username),
  UNIQUE(campaign_id, sid_hash)
);
CREATE INDEX IF NOT EXISTS ix_spins_campaign_created ON spins(campaign_id, created_at DESC);
